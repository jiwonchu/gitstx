<template>
   <footer class="footer">
      <div class="inner">

        <div>
          <address>
            부산사무소 : (48059) 부산광역시 해운대구 센텀동로49 아이피파빌리온 8층 TEL : 051-791-3000 · FAX : 051-791-3099<br>
            창원사무소 : (51494) 경상남도 창원시 성산구 중앙대로 84번길 3, 9층904호 · TEL : 055-263-2060 · FAX : 055-263-2087<br>

          </address>
          <span class="copy">Copyright ⓒ 2018 STX CONSTRUCTION. LTD. All Rights Reserved.</span>
        </div>

      </div>
    </footer>
</template>

<script>
export default {

}
</script>

<style>
.footer {
    background: url('../assets/images/logo_footer.png')no-repeat center;
    background-color: #4e4e4e;
    left: 30px;
  }

  .footer .inner {
    padding: 50px 0;
  }

  .footer-logo {

    width: 122px;
    height: 28px;

  }

  .footer p {
    display: inline-block;
  }

  .footer address {
    display: inline-block;
    color: #c3c3c3;
    font-size: 13px;
  }

  .footer .copy {
    display: inline-block;
    color: #c3c3c3;
    font-size: 13px;
  }
</style>